INSTALL INSTRUCTIONS:

Run the install.sh file to download all of the necessary materials needed to run Lightsaber Battles.

After this is complete, you can now play Lightsaber Battles by launching the binary file LightsaberBattles.out

NOTES: 
LightsaberBattles.out MUST be in the same directory as the contents folder for this game to run.

All source code for this version of the game can be found at https://github.com/markasfour/Lightsaber-Battles
