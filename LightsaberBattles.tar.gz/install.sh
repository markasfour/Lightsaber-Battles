sudo apt-get install libsdl2-dev libsdl2-mixer-dev libsdl2-ttf-dev libsdl2-image-dev

echo "Successfully installed!"

./LightsaberBattles.out
